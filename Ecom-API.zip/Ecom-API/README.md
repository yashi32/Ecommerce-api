# Ecom-API
<h1>API for E-Commerce platform</h1>

<h3>Designed an API for Ecommerce platform to manage product inventory </h3>

<h2>Install Dependices</h2>
<ul>
  <li> npm install express</li>
  <l1> npm install express<li>
</ul>

<h2> Start the app</h2>
  <p> node index.js </p>

<h1> REST API</h1>
    <h3> API Endpoints</h3>



<ul>
  
  <li><strong>Create Product:</strong> http://localhost:3000/products/create </li>
  <li><strong>Read all the products:</strong> http://localhost:3000/products </li>
  <li><strong>Update product quantity:</strong> http://localhost:3000/products/:id/update_quantity/?number=10 </li>
  <li><strong>Delete product:</strong> http://localhost:3000/products/:id </li>
</ul>
